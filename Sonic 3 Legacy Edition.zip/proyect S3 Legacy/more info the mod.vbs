msgbox ("this mod was made by El Mercenario JT Y Legacy Team"), vbinformation, "Sonic 3 Legacy Edition"
msgbox ("este mod fue hecho por El Mercenario JT Y Legacy Team"), vbinformation, "Sonic 3 Legacy Edition"
msgbox ("Disfrutar,enjoy"), vbinformation, "ok"
Set variable = CreateObject("WScript.Shell")
msgbox ("suscribete a mi canal"), vbinformation, "suscribete"
variable.Run "https://www.youtube.com/channel/UCJ3vPm_e_S5PaeCH5RcXElw"
variable.Run "https://gamebanana.com/mods/402492"