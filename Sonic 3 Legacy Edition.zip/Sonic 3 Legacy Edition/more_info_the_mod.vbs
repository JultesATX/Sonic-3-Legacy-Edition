Dim language
language = InputBox("Choose language/Elige idioma:" & vbCrLf & "1. English" & vbCrLf & "2. Español", "Language/Idioma")

If language = 1 Then
    MsgBox "This mod was made by El Mercenario JT and Legacy Team", vbInformation, "Sonic 3 Legacy Edition"
    MsgBox "Enjoy!", vbInformation, "OK"
    Set variable = CreateObject("WScript.Shell")
    MsgBox "Subscribe to my channel", vbInformation, "Subscribe"
    If MsgBox("Do you want to open the YouTube link?", vbYesNo + vbQuestion, "Open Link") = vbYes Then
        variable.Run "https://www.youtube.com/channel/UCJ3vPm_e_S5PaeCH5RcXElw"
    End If
    If MsgBox("Do you want to open the GameBanana link?", vbYesNo + vbQuestion, "Open Link") = vbYes Then
        variable.Run "https://gamebanana.com/mods/402492"
    End If
ElseIf language = 2 Then
    MsgBox "Este mod fue hecho por El Mercenario JT y Legacy Team", vbInformation, "Sonic 3 Legacy Edition"
    MsgBox "¡Disfruta!", vbInformation, "OK"
    Set variable = CreateObject("WScript.Shell")
    MsgBox "Suscríbete a mi canal", vbInformation, "Suscríbete"
    If MsgBox("¿Quieres abrir el enlace de YouTube?", vbYesNo + vbQuestion, "Abrir enlace") = vbYes Then
        variable.Run "https://www.youtube.com/channel/UCJ3vPm_e_S5PaeCH5RcXElw"
    End If
    If MsgBox("¿Quieres abrir el enlace de GameBanana?", vbYesNo + vbQuestion, "Abrir enlace") = vbYes Then
        variable.Run "https://gamebanana.com/mods/402492"
    End If
Else
    MsgBox "Invalid choice/Selección no válida", vbExclamation, "Error"
End If
